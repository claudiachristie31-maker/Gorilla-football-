// JNI bridge for NickoyClient. This is a control bridge, not a rendered overlay.
#include <jni.h>

extern "C" void NickoyClient_SetEnabled(int on);
extern "C" const char* NickoyClient_Status();
extern "C" void NickoyClient_SetFlyEnabled(int on);
extern "C" int NickoyClient_IsFlyEnabled();
extern "C" void NickoyClient_SetFlySpeed(float speed);
extern "C" float NickoyClient_GetFlySpeed();

extern "C" JNIEXPORT void JNICALL
Java_com_nickoy_Menu_setAutoCatch(JNIEnv*, jclass, jboolean on) {
    NickoyClient_SetEnabled(on == JNI_TRUE ? 1 : 0);
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_nickoy_Menu_getAutoCatch(JNIEnv*, jclass) {
    return NickoyClient_Status()[10] == 'o' && NickoyClient_Status()[11] == 'f'
        ? JNI_FALSE : JNI_TRUE;
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_nickoy_Menu_getStatus(JNIEnv* env, jclass) {
    return env->NewStringUTF(NickoyClient_Status());
}
extern "C" JNIEXPORT void JNICALL
Java_com_nickoy_Menu_setFly(JNIEnv*, jclass, jboolean on) {
    NickoyClient_SetFlyEnabled(on == JNI_TRUE ? 1 : 0);
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_nickoy_Menu_getFly(JNIEnv*, jclass) {
    return NickoyClient_IsFlyEnabled() ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_nickoy_Menu_setFlySpeed(JNIEnv*, jclass, jfloat speed) {
    NickoyClient_SetFlySpeed(speed);
}
extern "C" JNIEXPORT jfloat JNICALL
Java_com_nickoy_Menu_getFlySpeed(JNIEnv*, jclass) {
    return NickoyClient_GetFlySpeed();
}
