// NickoyClient — safe ARM64 IL2CPP integration scaffold.
// Unverified RVAs/signatures are deliberately NOT invoked.
#include <jni.h>
#include <android/log.h>
#include <link.h>
#include <atomic>
#include <cstdint>
#include <cstring>

#define TAG "NickoyClient"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static std::atomic<bool> g_autoCatch{true};
static std::atomic<bool> g_flyEnabled{false};
static std::atomic<float> g_flySpeed{1.0f};
static std::atomic<uintptr_t> g_il2cppBase{0};

static int find_il2cpp_callback(dl_phdr_info* info, size_t, void* data) {
    if (!info || !info->dlpi_name || !data) return 0;
    if (std::strstr(info->dlpi_name, "libil2cpp.so")) {
        *static_cast<uintptr_t*>(data) = static_cast<uintptr_t>(info->dlpi_addr);
        return 1;
    }
    return 0;
}

static uintptr_t find_il2cpp_base() {
    uintptr_t base = 0;
    dl_iterate_phdr(find_il2cpp_callback, &base);
    return base;
}

extern "C" __attribute__((visibility("default"))) uintptr_t NickoyClient_GetIl2CppBase() {
    return g_il2cppBase.load(std::memory_order_acquire);
}

// Kept for source/API compatibility. No arbitrary game methods are called here:
// method RVAs and native signatures must be verified against this exact game build.
extern "C" __attribute__((visibility("default"))) void Nickoy_ForceCatch(void* catcher, void* baseball) {
    if (!g_autoCatch.load(std::memory_order_relaxed)) return;
    if (!catcher || !baseball) {
        LOGE("ForceCatch rejected: null argument");
        return;
    }
    LOGE("ForceCatch not active: IL2CPP RVAs/signatures have not been verified");
}

extern "C" __attribute__((visibility("default"))) const char* NickoyClient_Status() {
    return g_autoCatch.load() ? "autocatch:on" : "autocatch:off";
}

extern "C" __attribute__((visibility("default"))) void NickoyClient_SetEnabled(int on) {
    g_autoCatch.store(on != 0, std::memory_order_relaxed);
}

// Fly state/control API. Actual movement requires the game's verified movement API.
extern "C" __attribute__((visibility("default"))) void NickoyClient_SetFlyEnabled(int on) {
    g_flyEnabled.store(on != 0, std::memory_order_relaxed);
}
extern "C" __attribute__((visibility("default"))) int NickoyClient_IsFlyEnabled() {
    return g_flyEnabled.load(std::memory_order_relaxed) ? 1 : 0;
}
extern "C" __attribute__((visibility("default"))) void NickoyClient_SetFlySpeed(float speed) {
    if (speed < 0.1f) speed = 0.1f;
    if (speed > 20.0f) speed = 20.0f;
    g_flySpeed.store(speed, std::memory_order_relaxed);
}
extern "C" __attribute__((visibility("default"))) float NickoyClient_GetFlySpeed() {
    return g_flySpeed.load(std::memory_order_relaxed);
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env = nullptr;
    if (!vm || vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK)
        return JNI_ERR;
    const uintptr_t base = find_il2cpp_base();
    g_il2cppBase.store(base, std::memory_order_release);
    LOGI("libil2cpp base: %p", reinterpret_cast<void*>(base));
    if (!base) LOGE("libil2cpp.so not found yet; retry after the game loads it");
    LOGI("NickoyClient scaffold loaded; unverified game calls remain disabled");
    return JNI_VERSION_1_6;
}
