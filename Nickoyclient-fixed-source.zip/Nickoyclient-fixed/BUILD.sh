#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_NDK_HOME:=${ANDROID_NDK_ROOT:-}}"
if [[ -z "$ANDROID_NDK_HOME" ]]; then
  echo "Set ANDROID_NDK_HOME to your Android NDK directory" >&2
  exit 1
fi
HOST_TAG=linux-x86_64
CXX="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/$HOST_TAG/bin/aarch64-linux-android21-clang++"
if [[ ! -x "$CXX" ]]; then echo "NDK compiler not found: $CXX" >&2; exit 1; fi
"$CXX" -shared -fPIC -O2 -std=c++17 -fvisibility=hidden \
  -Wl,--no-undefined -o libNickoyclient.so autocatch.cpp menu.cpp -llog -ldl
echo "Built libNickoyclient.so"
