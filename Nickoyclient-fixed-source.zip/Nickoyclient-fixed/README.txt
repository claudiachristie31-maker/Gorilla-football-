NickoyClient source repair
==========================

What was corrected:
- Removed the unsafe dlopen-handle-as-base assumption.
- Resolve the loaded ELF base using dl_iterate_phdr.
- Use atomic state for Auto Catch/Fly toggles and Fly speed.
- Preserve the original Auto Catch JNI methods.
- Add JNI controls for Fly enabled state and speed.
- Add a reproducible NDK build script.

Important limitations:
- This is a safe integration scaffold, not a working game cheat or finished mod.
- The original three RVAs and their function signatures are unverified. ForceCatch
  therefore logs and returns instead of calling arbitrary addresses.
- Fly currently stores its enabled state and speed only. Actual player movement
  requires a verified, build-matched movement method/API and its correct signature.
- menu.cpp is a JNI bridge, not a visible on-screen menu. A Java/Kotlin UI or a
  supported in-game UI renderer must call these JNI methods.
- JNI_OnLoad may run before libil2cpp.so is loaded; in that case the base is zero.
  A production integration should retry after the library is loaded.

Build:
  export ANDROID_NDK_HOME=/path/to/android-ndk
  ./BUILD.sh

Output: libNickoyclient.so (AArch64, Android API 21+)
